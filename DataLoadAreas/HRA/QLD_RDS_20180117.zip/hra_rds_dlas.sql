-- *********************************************************************
--
-- Version      Who         Date       Why
-- 01.00        Ian Rowell  25-Sep-09  Initial Creation
--
-- *********************************************************************
--
INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                   SELECT  'HRA',
                            'RDS_AUTHORITIES',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                    FROM    SYS.DUAL
                    WHERE NOT EXISTS (SELECT NULL
                                      FROM DL_LOAD_AREAS DLA
                                      WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                      AND DLA.DLA_DATALOAD_AREA = 'RDS_AUTHORITIES'); 

INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,
                           DLA_LOAD_ALLOWED,
                           DLA_QUESTION1,
                           DLA_QUESTION2,
                           DLA_PACKAGE_NAME)
                   SELECT  'HRA',
                            'RDS_AUTH_DEDUCTIONS',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                    FROM    SYS.DUAL
                    WHERE NOT EXISTS (SELECT NULL
                                      FROM DL_LOAD_AREAS DLA
                                      WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                      AND DLA.DLA_DATALOAD_AREA = 'RDS_AUTH_DEDUCTIONS');

INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,
                           DLA_LOAD_ALLOWED,
                           DLA_QUESTION1,
                           DLA_QUESTION2,
                           DLA_PACKAGE_NAME)
                   SELECT  'HRA',
                            'RDS_ACC_DEDUCTIONS',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                    FROM    SYS.DUAL
                    WHERE NOT EXISTS (SELECT NULL
                                      FROM DL_LOAD_AREAS DLA
                                      WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                      AND DLA.DLA_DATALOAD_AREA = 'RDS_ACC_DEDUCTIONS');

INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_INSTRUCTIONS',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_INSTRUCTIONS'); 

                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_ALLOCATIONS',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_ALLOCATIONS'); 

                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_ACCOUNT_ALLOCS',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_ACCOUNT_ALLOCS'); 

                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_TRANS_FILES',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_TRANS_FILES'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_ERRORS',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_ERRORS'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_PYI100',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_PYI100'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_PYI110',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_PYI110'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_PYI500',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_PYI500'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_PYI510',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_PYI510'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_PYI512',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_PYI512'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_PYI513',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_PYI513'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_PYI520',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_PYI520'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_PYI530',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_PYI530'); 


                    


INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                  SELECT   'HRA',
                           'RDS_PYI540',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                  FROM SYS.DUAL
                  WHERE NOT EXISTS (SELECT NULL
                                    FROM DL_LOAD_AREAS DLA
                                    WHERE DLA.DLA_PRODUCT_AREA = 'HRA'
                                    AND DLA.DLA_DATALOAD_AREA = 'RDS_PYI540'); 



 