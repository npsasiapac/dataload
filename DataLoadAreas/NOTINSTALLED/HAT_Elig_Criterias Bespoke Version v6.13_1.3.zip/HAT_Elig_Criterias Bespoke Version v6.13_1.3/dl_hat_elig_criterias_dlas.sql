--------------------------------------------------------------------
--
--
-- Date          Ver  DB Ver Name  Amendment(s)
-- ----          ---  ------ ----  ------------
--
-- 18-DEC-2014   1.0  6.10   AJ    Initial Creation for LCC Besopke
-- 04-FEB-2016   1.1  6.13   AJ    Added Change Control only for
--                                 New Brunswick Bespoke
--
--------------------------------------------------------------------
--
--
INSERT INTO DL_LOAD_AREAS (DLA_PRODUCT_AREA,
                           DLA_DATALOAD_AREA,               
                           DLA_LOAD_ALLOWED,             
                           DLA_QUESTION1,                           
                           DLA_QUESTION2,                            
                           DLA_PACKAGE_NAME)
                   SELECT   'HAT',
                            'ELIG_CRITERIAS',
                            'Y',
                            NULL,
                            NULL,
                            NULL
                    FROM    SYS.DUAL
                    WHERE NOT EXISTS (SELECT NULL
                                        FROM DL_LOAD_AREAS DLA
                                       WHERE DLA.DLA_PRODUCT_AREA =  'HAT'
                                         AND DLA.DLA_DATALOAD_AREA = 'ELIG_CRITERIAS');
/

