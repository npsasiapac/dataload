--------------------------------------------------------------------
--
--
-- Date          Ver  DB Ver Name  Amendment(s)
-- ----          ---  ------ ----  ------------
--
-- 18-AUG-2014   1.0  6.10   AJ    Initial Creation for LCC Besopke
-- 04-FEB-2016   1.1  6.13   AJ    Added Change Control and altered
--                                 names to match amended names
--                                 done for New Brunswick Bespoke
--
--------------------------------------------------------------------
--
--
spool gen_hat_elig_criterias
@dl_hat_elig_criterias_tab_new.sql
@dl_hat_elig_criterias_dlas.sql
@s_dl_hat_elig_criterias.pks
@s_dl_hat_elig_criterias_GNB.pkb
@hdl_grants_hat_elig_criterias.sql
@hdl_synonyms_hat_elig_criterias.sql
@dl_indexes_hat_elig_criterias.sql
@hd2_errs_in.sql
spool off

