--
-- Install Script for Allocations Configuration Dataloads
-- 
-- Instructions
-- 1) save all files into the same folder
-- 2) from the folder start a SQLPLUS session as the HOU user
-- 3) at the sqlplus prompt type @hatconfig_install.sql. This will run this file and install all the Allocations config dataloaders
-- 4) copy the control files (*.ctl) to the $PROD_HOME/bin folder on the server
-- 
-- 
@dl_hatconfig_tab_new.sql
@hatconfig_dlas_in.sql
--@hdl_errs_in.sql
--@hd1_errs_in.sql
@s_dl_hat_alloc_prop_attrs.pks
@s_dl_hat_alloc_prop_attrs.pkb
@s_dl_hat_alloc_prop_types.pks
@s_dl_hat_alloc_prop_types.pkb
@s_dl_hat_elements.pks
@s_dl_hat_elements.pkb
@s_dl_hat_attributes.pks
@s_dl_hat_attributes.pkb
@s_dl_hat_lettings_areas.pks
@s_dl_hat_lettings_areas.pkb
@hdl_grants_hatconfig.sql
@hdl_synonyms_hatconfig.sql
@hdl_invalid_hatconfig.sql
@dl_hat_indexes.sql